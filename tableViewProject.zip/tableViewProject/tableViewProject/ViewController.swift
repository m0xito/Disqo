//
//  ViewController.swift
//  tableViewProject
//
//  Created by Movses Aghabekyan on 09.11.21.
//

import UIKit



class ViewController: UIViewController {
    let idCell = "MainCell"
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: idCell)
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return personArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: idCell) as! TableViewCell
        cell.label.text = personArray[indexPath.row].name
        cell.personImage.image = personArray[indexPath.row].photo
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
}

extension ViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondVC = storyboard.instantiateViewController(withIdentifier: "person1") as! SecondViewController
        secondVC.personNameText = personArray[indexPath.row].name
        secondVC.personPhotoImage = personArray[indexPath.row].photo
        secondVC.personDescriptionText = personArray[indexPath.row].desctiptions
//        secondVC.personDescriptionText = personArray[indexPath.row]
        self.navigationController?.pushViewController(secondVC, animated: true)
        
        
    }
    
    

}
